/* Gota a Gota — JavaScript puro, sem dependências */
"use strict";

/* ===== Menu responsivo ===== */
(function menu() {
  const botao = document.getElementById("menuToggle");
  const nav = document.getElementById("menuPrincipal");

  function definir(aberto) {
    nav.classList.toggle("open", aberto);
    botao.setAttribute("aria-expanded", String(aberto));
    botao.setAttribute("aria-label", aberto ? "Fechar menu" : "Abrir menu");
  }

  botao.addEventListener("click", () => definir(!nav.classList.contains("open")));
  nav.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => definir(false)));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") definir(false);
  });
})();

/* ===== Calculadora de água no banho ===== */
const Calculadora = {
  // Fórmulas transparentes
  litrosPorBanho(minutos, vazao) { return minutos * vazao; },
  litrosPorDia(porBanho, banhos) { return porBanho * banhos; },
  litrosPorMes(porDia) { return porDia * 30; },
};

(function calculadora() {
  const form = document.getElementById("calcForm");
  const erro = document.getElementById("calcErro");
  const fmt = (n) => n.toLocaleString("pt-BR", { maximumFractionDigits: 1 });
  const fmtL = (n) => fmt(n) + " L";
  const fmtReal = (n) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  function ler(id) {
    const v = parseFloat(document.getElementById(id).value.replace(",", "."));
    return v;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const duracao = ler("duracao");
    const banhos = ler("banhos");
    const vazao = ler("vazao");
    let reducao = ler("reducao");
    const tarifa = ler("tarifa");

    if (![duracao, banhos, vazao].every((n) => Number.isFinite(n) && n > 0)) {
      erro.textContent = "Informe valores maiores que zero para duração, banhos e vazão.";
      erro.hidden = false;
      return;
    }
    erro.hidden = true;
    if (!Number.isFinite(reducao) || reducao < 0) reducao = 0;
    // Não permite reduzir mais do que a duração atual
    const duracaoNova = Math.max(0, duracao - reducao);

    const porBanho = Calculadora.litrosPorBanho(duracao, vazao);
    const porDia = Calculadora.litrosPorDia(porBanho, banhos);
    const porMes = Calculadora.litrosPorMes(porDia);

    const porBanhoNovo = Calculadora.litrosPorBanho(duracaoNova, vazao);
    const porMesNovo = Calculadora.litrosPorMes(Calculadora.litrosPorDia(porBanhoNovo, banhos));
    const economiaMes = porMes - porMesNovo;

    document.getElementById("resBanho").textContent = fmtL(porBanho);
    document.getElementById("resDia").textContent = fmtL(porDia);
    document.getElementById("resMes").textContent = fmtL(porMes);

    let texto = `Com banhos de ${fmt(duracaoNova)} min (${fmt(duracao - duracaoNova)} min a menos), o consumo mensal estimado cairia para ${fmtL(porMesNovo)}, uma economia de cerca de ${fmtL(economiaMes)} por mês.`;
    // Valor em reais apenas se o usuário informou a tarifa (R$/m³; 1 m³ = 1000 L)
    if (Number.isFinite(tarifa) && tarifa > 0) {
      texto += ` Com a tarifa informada, isso equivale a aproximadamente ${fmtReal((economiaMes / 1000) * tarifa)} por mês (considerando apenas a tarifa de água informada; a conta real pode ter outros componentes, como esgoto).`;
    }
    document.getElementById("compTexto").textContent = texto;

    document.getElementById("barAtual").style.width = "100%";
    document.getElementById("barNovo").style.width = (porMes > 0 ? (porMesNovo / porMes) * 100 : 0) + "%";

    document.getElementById("calcVazio").hidden = true;
    document.getElementById("calcSaida").hidden = false;
  });
})();

/* ===== Jogo: encontre os vazamentos ===== */
(function jogo() {
  const spots = Array.from(document.querySelectorAll("#casa .spot"));
  const bg = document.querySelector("#casa .g-bg");
  const elEnc = document.getElementById("gEncontrados");
  const elPts = document.getElementById("gPontos");
  const elErr = document.getElementById("gErros");
  const msg = document.getElementById("gMsg");
  const final = document.getElementById("gFinal");
  const resumo = document.getElementById("gResumo");
  const listaDicas = document.getElementById("gDicas");
  const total = spots.length;

  let encontrados, pontos, erros;

  function atualizar() {
    elEnc.textContent = encontrados;
    elPts.textContent = pontos;
    elErr.textContent = erros;
  }

  function reiniciar() {
    encontrados = 0; pontos = 0; erros = 0;
    spots.forEach((s) => s.classList.remove("found"));
    final.hidden = true;
    listaDicas.innerHTML = "";
    msg.textContent = "Clique nos pontos de desperdício que você encontrar.";
    atualizar();
  }

  function acertar(spot) {
    if (spot.classList.contains("found")) return;
    spot.classList.add("found");
    encontrados++;
    pontos += 10;
    msg.textContent = "✔ Achou! " + spot.dataset.dica;
    atualizar();
    if (encontrados === total) terminar();
  }

  function errar() {
    erros++;
    pontos = Math.max(0, pontos - 2);
    msg.textContent = "Aqui não há desperdício. Tente outro ponto (−2 pontos).";
    bg.classList.remove("erro");
    void bg.getBoundingClientRect(); // reinicia a animação
    bg.classList.add("erro");
    atualizar();
  }

  function terminar() {
    resumo.textContent = `Pontuação final: ${pontos} ponto(s), com ${erros} erro(s). Lembre-se destas dicas de prevenção:`;
    listaDicas.innerHTML = "";
    spots.forEach((s) => {
      const li = document.createElement("li");
      li.textContent = s.dataset.dica;
      listaDicas.appendChild(li);
    });
    final.hidden = false;
    msg.textContent = "Fim de jogo! Veja as dicas abaixo.";
    final.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  spots.forEach((spot) => {
    spot.addEventListener("click", (e) => { e.stopPropagation(); acertar(spot); });
    spot.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); acertar(spot); }
    });
  });
  // Clique em área vazia = erro (somente enquanto o jogo não terminou)
  document.getElementById("casa").addEventListener("click", () => {
    if (encontrados < total) errar();
  });

  document.getElementById("gReiniciar").addEventListener("click", reiniciar);
  document.getElementById("gDeNovo").addEventListener("click", reiniciar);
  reiniciar();
})();

/* ===== Compromisso (local e temporário, nada é enviado) ===== */
(function compromisso() {
  const form = document.getElementById("compForm");
  const erro = document.getElementById("compErro");
  const caixa = document.getElementById("compMsg");

  const mensagens = {
    banho: "🚿 Ótima escolha! Reduzir o banho é uma das formas mais eficazes de economizar. Tente começar com 1 minuto a menos.",
    dentes: "🪥 Pequeno gesto, grande efeito! Fechar a torneira enquanto escova vira hábito rápido.",
    vazamento: "🔧 Excelente! Procurar vazamentos protege sua casa e evita desperdício silencioso.",
    compartilhar: "💬 Que bonito! Quando uma dica passa de casa em casa, a comunidade inteira ganha.",
  };

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const escolhida = form.querySelector('input[name="atitude"]:checked');
    if (!escolhida) {
      erro.hidden = false;
      caixa.hidden = true;
      return;
    }
    erro.hidden = true;
    caixa.textContent = mensagens[escolhida.value] + " Obrigado por fazer a sua parte!";
    caixa.hidden = false;
  });
  form.addEventListener("change", () => { erro.hidden = true; });
})();
