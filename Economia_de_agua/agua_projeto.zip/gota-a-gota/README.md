# Gota a Gota — Economia de água e consumo consciente

Site educativo para um projeto de extensão universitária. Usa apenas HTML5, CSS3 e JavaScript puro, sem frameworks, bibliotecas externas ou back-end.

## Como executar

1. Extraia o ZIP.
2. Abra o arquivo `index.html` no navegador (clique duas vezes). Não precisa de internet nem de servidor.

## Estrutura

```
index.html   → estrutura e conteúdo
style.css    → design e responsividade
script.js    → menu, calculadora, jogo e compromisso
README.md    → este arquivo
```

## Funcionalidades

- Menu responsivo (hambúrguer em telas pequenas, fecha com Esc)
- Dicas práticas de economia de água
- Consumo consciente (sem números de pegada hídrica, de propósito)
- Calculadora do banho: consumo por banho, dia e mês, comparação com banho mais curto e valor em reais somente se a tarifa for informada
- Jogo "Encontre os vazamentos": 5 pontos, pontuação, erros, feedback visual, funciona com mouse, toque e teclado (Tab + Enter/Espaço)
- Compromisso comunitário local, sem coleta nem envio de dados
- Acessibilidade: link "ir para o conteúdo", foco visível, rótulos ARIA, respeito a `prefers-reduced-motion`

## Pendências para o grupo

- Preencher no rodapé: nome da universidade, integrantes e fontes consultadas (campos reservados em `index.html`).
- Se quiserem incluir valores de pegada hídrica, citar a fonte e a metodologia (ex.: Water Footprint Network, Embrapa, ANA).
- Revisar o texto com um profissional da área ambiental, se possível.

## Limitações conhecidas

- Os valores da calculadora são estimativas simples (minutos × vazão); o consumo real varia.
- A vazão de exemplo (9 L/min) é só um ponto de partida; o visitante deve medir a do próprio chuveiro.
- O jogo usa uma única ilustração fixa em SVG; o compromisso não é salvo ao recarregar a página.
- Testado em lógica e sintaxe; recomenda-se testar visualmente em celular e em diferentes navegadores.
